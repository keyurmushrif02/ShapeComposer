package composite;

import java.awt.*;


public abstract class DrawShape {
    private int a = 0;
    private int b = 0;
    private int a1 = 0;
    private int b1 = 0;   
    private Graphics graphics;
    
   
    public  abstract void paint();
    public void add(DrawShape s) {};
 
}
