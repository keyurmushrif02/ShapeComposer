package composite;

import java.awt.*;

public class DrawShapeBox extends DrawShape {

	private final Graphics graphics;
    private final int a;
    private final int b;
    
    public DrawShapeBox() {
    	this.b = 0;
    	this.a = 0;
    	this.graphics=null;
    }

    public DrawShapeBox(int a, int b, Graphics graphics) {
    	if (graphics == null) {
    		throw new IllegalArgumentException("grpahics should not null");
    		
    	}
        this.graphics = graphics;
        this.a = a;
        this.b = b;
    }

    @Override
    public void paint() {
        this.graphics.drawRect(this.a, this.b, 120, 120);
    }

}


