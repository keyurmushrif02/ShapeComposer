package composite;

import java.awt.*;

public class DrawShapeCircle extends DrawShape {

    private int a,b;
    private Graphics graphics;
    
    public DrawShapeCircle() {    }

    public DrawShapeCircle(int a, int b, Graphics graphics) {
    	if (graphics == null) {
    		throw new IllegalArgumentException("grpahics should not null");
    		
    	}
        this.a = a;
        this.b = b;
        this.graphics = graphics;
    }

    @Override
    public void paint() {
        this.graphics.drawOval(this.a, this.b, 120, 120);
    }

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public Graphics getGraphics() {
		return graphics;
	}

	public void setGraphics(Graphics graphics) {
		this.graphics = graphics;
	}
    
    
}

