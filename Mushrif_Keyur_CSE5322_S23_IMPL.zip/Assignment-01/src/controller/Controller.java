package controller;

import composite.DrawShape; 
import composite.DrawShapeCircle;
import composite.DrawShapeTriangle;
import composite.DrawShapeBox;
import iterator.Composite;
import expert.Enum;

import java.awt.*;

public class Controller {

    Enum drawShapes;
    Composite shape;

    public Controller() {
        super();
        this.shape = new Composite();
    }

    public void clickToDraw(int a, int b, Graphics g) {
        switch(this.drawShapes) {
            case BOXSHAPE:
                this.shape.add(new DrawShapeBox(a,b,g));
                break;
            case CIRCLESHAPE:
                this.shape.add(new DrawShapeCircle(a,b,g));
                break;
            case TRIANGLESHAPE:
            	int a1 = a; int b1 = b - 50; int a2 = a - 50; int b2 = b + 50; int a3 = a + 50; int b3 = b + 50;
            	this.shape.add(new DrawShapeTriangle(a1,b1,a2,b2,a3,b3,g));
            	break;
            default:
                System.out.println("Error:Shape selection is invalid");
                break;
        }
        this.shape.paint();
    }

    public void circleClickButton() {
        this.drawShapes = Enum.CIRCLESHAPE;
    }

    public void boxClickButton() {
        this.drawShapes = Enum.BOXSHAPE;
    }
    
    public void triangleClickButton() {
    	this.drawShapes = Enum.TRIANGLESHAPE;
    }


    
}
