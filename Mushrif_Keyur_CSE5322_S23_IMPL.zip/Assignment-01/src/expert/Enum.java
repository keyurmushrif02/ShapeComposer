package expert;

public enum Enum {
    BOXSHAPE,CIRCLESHAPE,TRIANGLESHAPE
}

