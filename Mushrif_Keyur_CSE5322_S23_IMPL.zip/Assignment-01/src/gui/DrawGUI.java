package gui;

import controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class DrawGUI extends JFrame {

    private static final long serialVersionUID = 1L;
	private Area canvas = new Area();
    private JButton box = new JButton("Box");
    private JButton circle = new JButton("Circle");
    private JButton triangle = new JButton("Triangle");

    Controller controller = new Controller();
    
    public DrawGUI() {
        super();
        try {
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            setTitle("SDP ASSIGNMENT-01");
            addWindowListener((WindowListener) new WindowAdapter() {
            	public void windowClosing(WindowEvent e) {
            	}
            	
            });
            init();
        } catch(Exception e) {
            System.out.println(e);
        }
    }

    private void init() {
    	JPanel window = (JPanel) getContentPane();
    	canvas.setVisible(true);
    	setSize(new Dimension(1150, 815));
    	setTitle("HW1 GUI");
    	box.setPreferredSize(new Dimension(55, 55));
    	circle.setPreferredSize(new Dimension(55, 55));
    	triangle.setPreferredSize(new Dimension(55, 55));
    	
    	JPanel button = new JPanel();
    	button.setLayout(new BoxLayout(button, BoxLayout.Y_AXIS));
    	button.setPreferredSize(new Dimension(55, 105));
    	
    	button.add(circle);
    	button.add(box);
    	button.add(triangle);
    	
    	
    	window.add(button, BorderLayout.NORTH);
    	window.add(canvas, BorderLayout.CENTER);

    	box.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controller.boxClickButton();
                box.setBackground(Color.BLUE);
                
            }
        });

    	circle.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controller.circleClickButton();
                circle.setBackground(Color.BLUE);
            }
        });
        
        
        triangle.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controller.triangleClickButton();
                triangle.setBackground(Color.BLUE);
            }
        });

        canvas.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                Graphics g = canvas.getGraphics();
                controller.clickToDraw( (int) e.getPoint().getX(),
                        (int) e.getPoint().getY(), g);
            }
        });
    }

    public static void main(String args[])
    {
        EventQueue.invokeLater(() -> {           
                try {
                    DrawGUI window = new DrawGUI();
                    window.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            
        });
    }


  
}

