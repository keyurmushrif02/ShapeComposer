package iterator;

import java.awt.Shape;
import java.util.ArrayList;
import java.util.List;
import composite.DrawShape;

import java.util.Iterator;


public class Composite extends DrawShape {
    private List<DrawShape> shapeList = new ArrayList<>();
    
    public void add(DrawShape s) {
        shapeList.add(s);
    }
    @Override
    public void paint() {
        for(DrawShape shape : shapeList) {
        	shape.paint();
        }
    }
}

 